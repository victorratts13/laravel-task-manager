<?php

namespace App\Forms\Components;

use Filament\Forms\Components\Field;

class InternalPath extends Field
{
    protected string $view = 'forms.components.internal-path';
}
