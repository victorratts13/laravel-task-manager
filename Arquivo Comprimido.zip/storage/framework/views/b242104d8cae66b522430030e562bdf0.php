<div>
    <?php if (isset($component)) { $__componentOriginal2d3e6b52b2eab45c791560108ee8ee7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d3e6b52b2eab45c791560108ee8ee7b = $attributes; } ?>
<?php $component = WireUi\Components\Alert\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Alert\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Success Message!','positive' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d3e6b52b2eab45c791560108ee8ee7b)): ?>
<?php $attributes = $__attributesOriginal2d3e6b52b2eab45c791560108ee8ee7b; ?>
<?php unset($__attributesOriginal2d3e6b52b2eab45c791560108ee8ee7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3e6b52b2eab45c791560108ee8ee7b)): ?>
<?php $component = $__componentOriginal2d3e6b52b2eab45c791560108ee8ee7b; ?>
<?php unset($__componentOriginal2d3e6b52b2eab45c791560108ee8ee7b); ?>
<?php endif; ?>
</div>
<?php /**PATH /Users/victorratts/Documents/Projects/php/Laravel/laravel-taskmanager/resources/views/livewire/home.blade.php ENDPATH**/ ?>