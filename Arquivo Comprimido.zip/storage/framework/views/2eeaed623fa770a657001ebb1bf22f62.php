<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'Page Title'); ?></title>
    
    <link rel="stylesheet" href="<?php echo e(asset('/tailwind/app.css')); ?>">
    
    
    <script >window.Wireui = {cache: {},hook(hook, callback) {window.addEventListener(`wireui:${hook}`, () => callback())},dispatchHook(hook) {window.dispatchEvent(new Event(`wireui:${hook}`))}}</script>
<script src="http://localhost:3000/wireui/assets/scripts?id=0d8f3f5397f3b35df10c017bfdd8593c" defer ></script>
    
</head>

<body>
    <?php echo e($slot); ?>

</body>





</html>
<?php /**PATH /Users/victorratts/Documents/Projects/php/Laravel/laravel-taskmanager/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>