<div>
    <x-alert title="Success Message!" positive />
</div>
