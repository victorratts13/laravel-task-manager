// resources/js/app.js
import flatpickr from "flatpickr"; 
import './../../vendor/power-components/livewire-powergrid/dist/tailwind.css';
import './../../vendor/power-components/livewire-powergrid/dist/powergrid';
import 'flatpickr/dist/flatpickr.min.css';

import './bootstrap';
